# ValueVault

MM2 (Murder Mystery 2) value list + trade calculator.

## Features (MVP)

- **Values** — search, rarity filters, Vault vs Supreme comparison, demand bars, stability
- **Calculator** — add items to both sides → WIN / FAIR / LOSE

## Run

```bash
cd valuevault
npm install
npm run dev
```

Open http://localhost:5173

## Data

Demo items live in `src/data/items.ts`. Replace / extend with live community list data.

## Stack

React 19 + TypeScript + Vite + plain CSS (dark theme)
