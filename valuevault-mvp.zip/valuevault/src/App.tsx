import { useMemo, useState } from 'react'
import { ITEMS, RARITIES } from './data/items'
import type { TradeSideItem } from './types'
import { formatValue, gapPercent } from './utils/format'

type Tab = 'values' | 'calculator'

function DemandBars({ n }: { n: number }) {
  return (
    <span className="demand" title={`Demand ${n}/10`}>
      {Array.from({ length: 10 }, (_, i) => (
        <i key={i} className={i < n ? 'on' : ''} />
      ))}
    </span>
  )
}

function ItemCard({ item }: { item: (typeof ITEMS)[0] }) {
  const gap = gapPercent(item.value, item.supremeValue)
  return (
    <article className="card">
      <div className="card-top">
        <div>
          <h3>{item.name}</h3>
          <div className="meta">
            {item.type}
            {item.year ? ` · ${item.year}` : ''}
          </div>
        </div>
        <span className={`badge badge-${item.rarity}`}>{item.rarity}</span>
      </div>
      <div className="values-row">
        <div className="val-box">
          <label>Vault Value</label>
          <strong>{formatValue(item.value)}</strong>
        </div>
        <div className="val-box">
          <label>Supreme</label>
          <strong>{formatValue(item.supremeValue)}</strong>
          {gap != null && (
            <div className="gap">
              {gap > 0 ? '+' : ''}
              {gap.toFixed(1)}% vs Supreme
            </div>
          )}
        </div>
      </div>
      <div className="foot">
        <DemandBars n={item.demand} />
        <span className={`stab-${item.stability}`}>{item.stability}</span>
      </div>
    </article>
  )
}

function SidePanel({
  title,
  lines,
  onRemove,
  onAdd,
}: {
  title: string
  lines: TradeSideItem[]
  onRemove: (id: string) => void
  onAdd: (itemId: string, qty: number) => void
}) {
  const [pick, setPick] = useState(ITEMS[0]?.id ?? '')
  const [qty, setQty] = useState(1)
  const total = lines.reduce((s, l) => s + l.item.value * l.qty, 0)
  return (
    <div className="side">
      <h2>{title}</h2>
      {lines.length === 0 && (
        <p style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>Henüz item yok.</p>
      )}
      {lines.map((l) => (
        <div key={l.item.id} className="line">
          <span>
            {l.qty}× {l.item.name}
          </span>
          <span>
            {formatValue(l.item.value * l.qty)}{' '}
            <button type="button" onClick={() => onRemove(l.item.id)}>
              ✕
            </button>
          </span>
        </div>
      ))}
      <div className="add-row">
        <select value={pick} onChange={(e) => setPick(e.target.value)}>
          {ITEMS.map((i) => (
            <option key={i.id} value={i.id}>
              {i.name}
            </option>
          ))}
        </select>
        <input
          type="number"
          min={1}
          max={99}
          value={qty}
          onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))}
        />
        <button
          type="button"
          onClick={() => {
            onAdd(pick, qty)
            setQty(1)
          }}
        >
          Ekle
        </button>
      </div>
      <div className="side-total">
        <span>Toplam</span>
        <span>{formatValue(total)}</span>
      </div>
    </div>
  )
}

export default function App() {
  const [tab, setTab] = useState<Tab>('values')
  const [q, setQ] = useState('')
  const [rarity, setRarity] = useState('All')
  const [you, setYou] = useState<TradeSideItem[]>([])
  const [them, setThem] = useState<TradeSideItem[]>([])

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase()
    return ITEMS.filter((item) => {
      const matchR = rarity === 'All' || item.rarity === rarity
      const matchQ =
        !query ||
        item.name.toLowerCase().includes(query) ||
        item.type.toLowerCase().includes(query)
      return matchR && matchQ
    }).sort((a, b) => b.value - a.value)
  }, [q, rarity])

  const youTotal = you.reduce((s, l) => s + l.item.value * l.qty, 0)
  const themTotal = them.reduce((s, l) => s + l.item.value * l.qty, 0)
  const diff = themTotal - youTotal
  const pct = youTotal > 0 ? (diff / youTotal) * 100 : themTotal > 0 ? 100 : 0
  let verdict: 'win' | 'lose' | 'fair' | 'empty' = 'empty'
  if (youTotal > 0 || themTotal > 0) {
    if (Math.abs(pct) < 5) verdict = 'fair'
    else if (diff > 0) verdict = 'win'
    else verdict = 'lose'
  }

  const addTo = (
    setter: React.Dispatch<React.SetStateAction<TradeSideItem[]>>,
    itemId: string,
    qty: number,
  ) => {
    const item = ITEMS.find((i) => i.id === itemId)
    if (!item) return
    setter((prev) => {
      const existing = prev.find((p) => p.item.id === itemId)
      if (existing) {
        return prev.map((p) =>
          p.item.id === itemId ? { ...p, qty: p.qty + qty } : p,
        )
      }
      return [...prev, { item, qty }]
    })
  }

  return (
    <div className="app">
      <header className="header">
        <div className="logo">
          <div className="logo-mark">VV</div>
          <div>
            <h1>ValueVault</h1>
            <p>MM2 values · demand · trade checker</p>
          </div>
        </div>
        <nav className="tabs">
          <button
            type="button"
            className={`tab ${tab === 'values' ? 'active' : ''}`}
            onClick={() => setTab('values')}
          >
            Values
          </button>
          <button
            type="button"
            className={`tab ${tab === 'calculator' ? 'active' : ''}`}
            onClick={() => setTab('calculator')}
          >
            Calculator
          </button>
        </nav>
      </header>

      {tab === 'values' && (
        <>
          <div className="stats">
            <div className="stat">
              <span>Items</span>
              <strong>{ITEMS.length}</strong>
            </div>
            <div className="stat">
              <span>Showing</span>
              <strong>{filtered.length}</strong>
            </div>
            <div className="stat">
              <span>Updated</span>
              <strong>Demo</strong>
            </div>
          </div>
          <div className="toolbar">
            <input
              className="search"
              placeholder="Search knife, gun, chroma…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <div className="filters">
            {RARITIES.map((r) => (
              <button
                key={r}
                type="button"
                className={`chip ${rarity === r ? 'active' : ''}`}
                onClick={() => setRarity(r)}
              >
                {r}
              </button>
            ))}
          </div>
          {filtered.length === 0 ? (
            <div className="empty">Sonuç yok. Filtreyi veya aramayı değiştir.</div>
          ) : (
            <div className="grid">
              {filtered.map((item) => (
                <ItemCard key={item.id} item={item} />
              ))}
            </div>
          )}
        </>
      )}

      {tab === 'calculator' && (
        <div className="calc">
          <SidePanel
            title="Sen veriyorsun"
            lines={you}
            onRemove={(id) => setYou((p) => p.filter((x) => x.item.id !== id))}
            onAdd={(id, qty) => addTo(setYou, id, qty)}
          />
          <div className={`verdict ${verdict === 'empty' ? '' : verdict}`}>
            <div className="label">Sonuç</div>
            <div className="big">
              {verdict === 'empty' ? '—' : verdict.toUpperCase()}
            </div>
            {(youTotal > 0 || themTotal > 0) && (
              <div style={{ fontSize: '0.8rem', color: 'var(--muted)' }}>
                {diff >= 0 ? '+' : ''}
                {formatValue(diff)} ({pct >= 0 ? '+' : ''}
                {pct.toFixed(1)}%)
              </div>
            )}
          </div>
          <SidePanel
            title="Karşı taraf"
            lines={them}
            onRemove={(id) => setThem((p) => p.filter((x) => x.item.id !== id))}
            onAdd={(id, qty) => addTo(setThem, id, qty)}
          />
        </div>
      )}

      <p className="footer-note">
        ValueVault MVP · Demo veriler (topluluk listelerine yakın). Canlı feed yakında.
      </p>
    </div>
  )
}
