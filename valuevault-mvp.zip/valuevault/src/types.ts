export type Rarity =
  | 'Ancient'
  | 'Unique'
  | 'Chroma'
  | 'Godly'
  | 'Legendary'
  | 'Rare'
  | 'Uncommon'
  | 'Common'
  | 'Vintage'
  | 'Pet'
  | 'Misc';

export type Stability = 'Rising' | 'Stable' | 'Falling' | 'Volatile' | 'Unknown';

export interface MM2Item {
  id: string;
  name: string;
  rarity: Rarity;
  type: 'Knife' | 'Gun' | 'Pet' | 'Misc' | 'Set';
  value: number; // primary list (unitless points)
  supremeValue?: number | null;
  demand: number; // 1-10
  stability: Stability;
  year?: string;
}

export interface TradeSideItem {
  item: MM2Item;
  qty: number;
}
