export function formatValue(n: number | null | undefined): string {
  if (n == null || Number.isNaN(n)) return '—';
  if (n >= 1_000_000) {
    const m = n / 1_000_000;
    return m % 1 === 0 ? `${m}M` : `${m.toFixed(1)}M`;
  }
  if (n >= 1_000) {
    const k = n / 1_000;
    return k % 1 === 0 ? `${k}K` : `${k.toFixed(1)}K`;
  }
  return String(Math.round(n));
}

export function gapPercent(a: number, b: number | null | undefined): number | null {
  if (b == null || b === 0 || a === 0) return null;
  return ((a - b) / b) * 100;
}
